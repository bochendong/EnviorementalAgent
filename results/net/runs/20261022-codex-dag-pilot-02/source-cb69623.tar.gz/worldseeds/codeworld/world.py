"""CodeWorld: a procedurally generated software ecosystem with hidden behaviour.

A universe is a set of *modules* (auth, billing, geo, ...). Each module exposes functions with a public
signature (``billing.quote_price: Order -> Price``) and a hidden behaviour, its *law*. Values are integers
mod P. A law is either

    affine    f(x) = a*x + b                                     (mod P)
    branch    f(x) = a2*x + b2 if x % m == 0 else a*x + b        (an edge case: m in 2, 3, 5)

Types sit on levels and every function maps a type of level l to a type of level l+1, so a *program*
from type S to type G is a chain of functions of known length. Several functions, often in different
modules, share a signature, so many programs type-check but only one does what is wanted.

A *project* is a feature request: input type, output type and a few examples (x -> expected y), chosen so
that exactly one program among those that type-check (up to programs that compute the same thing) fits
them. Its target usually crosses several modules: building it means knowing how functions of several
modules behave. Running a function costs an action; so does studying a function to learn its law (probing
it on a fixed design of inputs). Knowing laws makes development cheap; the world can hold more laws than
one developer can keep in mind. Everything is scored exactly: every believed law, every program.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from functools import cached_property

P = 101  # values are integers mod P
DESIGN = (0, 1, 2, 3, 4, 5, 6, 7)  # the inputs a careful developer probes to learn a law (covers every edge case)
BRANCH_MODS = (2, 3, 5)

MODULE_NAMES = ["auth", "billing", "geo", "search", "cache", "mail", "crypto", "ledger", "ranking", "media",
                "i18n", "metrics", "queue", "storage", "users", "orders", "inventory", "pricing", "shipping",
                "tax", "feeds", "chat", "maps", "payroll", "audit", "forms", "reports", "notify", "sessions",
                "catalog", "reviews", "ads"]
TYPE_NAMES = ["UserId", "Email", "Token", "Session", "Order", "Cart", "Price", "Invoice", "Region", "Address",
              "Route", "Score", "Rank", "Query", "Doc", "Hash", "Locale", "Text", "Report", "Event", "Metric",
              "Payload", "Message", "Receipt", "Shipment", "Rate", "Tax", "Ledger", "Review", "Ad", "Feed", "Plan"]
VERBS = ["to", "make", "get", "parse", "quote", "hash", "map", "lookup", "encode", "rank", "route", "sign",
         "resolve", "build", "check", "derive"]

# the town theme: modules are workshops (in districts of 8), types are goods, functions are machines
WORKSHOPS = ["bakery", "smithy", "florist", "mine", "clinic", "inn", "shop", "farm"]
DISTRICTS = ["oak", "river", "hill", "sea", "pine", "stone", "fern", "moss", "lake", "dune", "ash", "elm",
             "glen", "cove", "peak", "vale"]
PER_DISTRICT = len(WORKSHOPS)


@dataclass(frozen=True)
class Law:
    kind: str  # "affine" | "branch"
    a: int
    b: int
    m: int = 0
    a2: int = 0
    b2: int = 0

    def __call__(self, x: int) -> int:
        if self.kind == "branch" and x % self.m == 0:
            return (self.a2 * x + self.b2) % P
        return (self.a * x + self.b) % P

    @cached_property
    def table(self) -> tuple[int, ...]:
        return tuple(self(x) for x in range(P))

    def describe(self) -> str:
        base = f"{self.a}*x + {self.b}"
        if self.kind == "branch":
            return f"{self.a2}*x + {self.b2} if x % {self.m} == 0 else {base} (mod {P})"
        return f"{base} (mod {P})"

    def to_dict(self) -> dict:
        return {"kind": self.kind, "a": self.a, "b": self.b, "m": self.m, "a2": self.a2, "b2": self.b2}


@dataclass(frozen=True)
class Function:
    name: str  # module.verb_type
    module: str
    in_type: str
    out_type: str
    law: Law = field(repr=False, compare=False)

    @property
    def signature(self) -> str:
        return f"{self.name}: {self.in_type} -> {self.out_type}"


@dataclass
class Project:
    id: str
    in_type: str
    out_type: str
    examples: list[tuple[int, int]]
    target: tuple[str, ...]  # hidden: one correct program
    n_candidates: int  # programs that type-check

    @property
    def length(self) -> int:
        return len(self.target)

    def text(self) -> str:
        ex = ", ".join(f"{x} -> {y}" for x, y in self.examples)
        return (f"Project {self.id}: build a program {self.in_type} -> {self.out_type} (a chain of {self.length} "
                f"functions) such that {ex}.")


class Universe:
    """One software ecosystem: modules, functions with hidden laws, and a stream of projects."""

    def __init__(self, index: int = 0, n_modules: int = 8, fns_per_module: int = 4, levels: int = 5,
                 types_per_level: int = 2, branch_share: float = 0.3, popularity: float = 1.0,
                 theme: str = "software", shortcuts: bool = False):
        self.index, self.levels, self.theme = index, levels, theme
        rng = random.Random(f"codeworld/{index}/{n_modules}/{fns_per_module}/{levels}/{types_per_level}"
                            + ("" if theme == "software" else f"/{theme}"))
        town = theme == "town"
        if town:  # workshops grouped in districts of 8 (a single district keeps the plain names)
            names = [WORKSHOPS[i % PER_DISTRICT] if n_modules <= PER_DISTRICT else
                     f"{DISTRICTS[(i // PER_DISTRICT) % len(DISTRICTS)]}"
                     f"{'' if i // PER_DISTRICT < len(DISTRICTS) else i // PER_DISTRICT}_{WORKSHOPS[i % PER_DISTRICT]}"
                     for i in range(n_modules)]
            self.kind_of = {m: WORKSHOPS[i % PER_DISTRICT] for i, m in enumerate(names)}
            self.district_of = {m: i // PER_DISTRICT for i, m in enumerate(names)}
        else:
            names = [MODULE_NAMES[i % len(MODULE_NAMES)] + (str(i // len(MODULE_NAMES) + 1)
                                                            if i >= len(MODULE_NAMES) else "") for i in range(n_modules)]
            self.kind_of = {m: m for m in names}
            self.district_of = {m: 0 for m in names}
        self.modules = names
        self.map = None
        self.room: dict[str, tuple[int, dict]] = {}  # module -> (area index, room)
        if town:  # the maps: every workshop is a room in the area of its kind (bakery in town, inn on the beach)
            from .townmap import TownMap

            nd = max(self.district_of.values()) + 1
            self.map = TownMap(nd, [DISTRICTS[d % len(DISTRICTS)] + ("" if d < len(DISTRICTS) else str(d))
                                    for d in range(nd)], seed=str(index), machines=fns_per_module,
                               shortcuts=shortcuts)
            for m in names:
                self.room[m] = self.map.room_of(self.district_of[m], self.kind_of[m])
        if town:  # goods by level and the machines of each trade come from the recipe book
            from .recipes import GOODS_BY_LEVEL, RECIPES

            levels = self.levels = len(GOODS_BY_LEVEL)
            tnames = [g for lv in GOODS_BY_LEVEL for g in lv]
            self.type_level = {g: lv for lv, gs in enumerate(GOODS_BY_LEVEL) for g in gs}
        else:
            tnames = [TYPE_NAMES[i % len(TYPE_NAMES)] + (str(i // len(TYPE_NAMES) + 1) if i >= len(TYPE_NAMES) else "")
                      for i in range(levels * types_per_level)]
            rng.shuffle(tnames)
            self.type_level = {t: i // types_per_level for i, t in enumerate(tnames)}
        self.types_at = {lv: [t for t in tnames if self.type_level[t] == lv] for lv in range(levels)}
        # module popularity: some modules are used far more than others (a long tail, like real code)
        self.weight = {m: 1.0 / (k + 1) ** popularity for k, m in enumerate(names)}
        self.functions: dict[str, Function] = {}
        for m in names:
            if town:  # this workshop's machines: fns_per_module of its trade's recipes
                book = RECIPES[self.kind_of[m]]
                for tool, t_in, t_out in sorted(rng.sample(book, min(fns_per_module, len(book))), key=book.index):
                    name = f"{m}.{tool}"
                    self.functions[name] = Function(name, m, t_in, t_out, self._law(rng, branch_share))
                continue
            used = set()
            for _ in range(fns_per_module):
                lv = rng.randrange(levels - 1)
                t_in, t_out = rng.choice(self.types_at[lv]), rng.choice(self.types_at[lv + 1])
                base = f"{m}.{rng.choice(VERBS)}_{t_out.lower()}"
                name, k = base, 2
                while name in self.functions or name in used:
                    name, k = f"{base}{k}", k + 1
                used.add(name)
                self.functions[name] = Function(name, m, t_in, t_out, self._law(rng, branch_share))
        self.out_of: dict[str, list[Function]] = {}
        for f in self.functions.values():
            self.out_of.setdefault(f.in_type, []).append(f)
        self._n_projects = 0
        # what random events have done to the world this sprint (see events.py)
        self.broken: dict[str, int] = {}  # machine -> sprints until it is repaired
        self.demand: dict[str, float] = {}  # good -> how much more often it is ordered
        self.storm: set[str] = set()  # maps where walking costs double

    @staticmethod
    def _law(rng: random.Random, branch_share: float) -> Law:
        a, b = rng.randrange(2, P), rng.randrange(P)
        if rng.random() < branch_share:
            a2 = rng.randrange(2, P)
            while a2 == a:
                a2 = rng.randrange(2, P)
            return Law("branch", a, b, rng.choice(BRANCH_MODS), a2, rng.randrange(P))
        return Law("affine", a, b)

    # ------------------------------------------------------------ programs
    def run(self, program, x: int) -> int:
        for name in program:
            x = self.functions[name].law(x)
        return x

    def table(self, program) -> tuple[int, ...]:
        t = tuple(range(P))
        for name in program:
            law = self.functions[name].law.table
            t = tuple(law[v] for v in t)
        return t

    def type_checks(self, program, in_type: str, out_type: str) -> bool:
        cur = in_type
        for name in program:
            f = self.functions.get(name)
            if f is None or f.in_type != cur:
                return False
            cur = f.out_type
        return cur == out_type

    def candidates(self, in_type: str, out_type: str, cap: int = 20000) -> list[tuple[str, ...]]:
        """Every program from in_type to out_type (they all have the same length: levels only go up)."""
        goal = self.type_level[out_type]
        out: list[tuple[str, ...]] = []

        def walk(t, path):
            if len(out) >= cap:
                return
            if t == out_type:
                out.append(tuple(path))
                return
            if self.type_level[t] >= goal:
                return
            for f in self.out_of.get(t, []):
                walk(f.out_type, path + [f.name])

        walk(in_type, [])
        return out

    # ------------------------------------------------------------ projects
    def project(self, rng: random.Random, min_len: int = 2, max_len: int = 4, min_modules: int = 2,
                tries: int = 200) -> Project:
        """A feature request whose examples single out one program (up to equivalent programs)."""
        for _ in range(tries):
            length = rng.randint(min_len, max_len)
            lv = rng.randrange(0, self.levels - length) if self.levels - length > 0 else 0
            t = rng.choice(self.types_at[lv])
            path = []
            for _ in range(length):
                opts = self.out_of.get(t, [])
                if not opts:
                    break
                f = rng.choices(opts, [self.weight[o.module] for o in opts])[0]
                path.append(f.name)
                t = f.out_type
            if len(path) < length or len({self.functions[n].module for n in path}) < min_modules:
                continue
            target = tuple(path)
            in_type = self.functions[target[0]].in_type
            cands = self.candidates(in_type, t)
            tt = self.table(target)
            others = {self.table(c) for c in cands} - {tt}
            examples: list[tuple[int, int]] = []
            xs = list(range(P))
            rng.shuffle(xs)
            for x in xs[:2]:
                examples.append((x, tt[x]))
            # add examples until no other behaviour fits them (edge cases included when they matter)
            alive = {o for o in others if all(o[x] == y for x, y in examples)}
            while alive and len(examples) < 8:
                o = next(iter(alive))
                x = next(x for x in xs if o[x] != tt[x])
                examples.append((x, tt[x]))
                alive = {o for o in alive if o[x] == tt[x]}
            if alive:
                continue
            if self.broken and any(fn in self.broken for fn in target):
                continue  # customers only order what can be made
            if self.demand and rng.random() > self.demand.get(t, 1.0) / max(self.demand.values()):
                continue  # a festival: its good is ordered more often
            self._n_projects += 1
            return Project(f"p{self._n_projects}", in_type, t, examples, target, len(cands))
        raise RuntimeError("could not generate a project; make the universe bigger")

    # ------------------------------------------------------------ text
    def signatures_text(self, modules=None) -> str:
        lines = []
        for m in modules or self.modules:
            fs = [f for f in self.functions.values() if f.module == m]
            lines.append(f"{m}: " + "; ".join(f"{f.name}: {f.in_type} -> {f.out_type}" for f in fs))
        return "\n".join(lines)

    @property
    def n_functions(self) -> int:
        return len(self.functions)

    @property
    def n_districts(self) -> int:
        return max(self.district_of.values()) + 1

    def where(self, place: str | None) -> tuple[int, int, int]:
        """Where one stands at a place: (area index, x, y) inside a workshop; None is the town plaza."""
        if not place:
            return self.map.plaza
        if ":" in place:  # a town building: "library:0", "post:1", "board:0"
            kind, d = place.split(":")
            a = next(i for i, ar in enumerate(self.map.areas) if ar.theme == "town" and ar.district == int(d))
            return (a, *self.map.areas[a].places[kind])
        a, r = self.room[place]
        return (a, *r["centre"])

    def route(self, a: str | None, b: str | None) -> tuple[tuple[int, int, int], ...]:
        """The shortest walk between two places, across areas (town theme)."""
        return self.map.route(self.where(a), self.where(b))

    def distance(self, a: str | None, b: str | None) -> int:
        """Walking cost between two places (workshops, or None for the plaza): in the town, one action per
        TILES_PER_ACTION tiles of the shortest walk; without a map, 1 between any two places. Same place: 0."""
        if a == b:
            return 0
        if self.map is None:
            return 1
        path = self.route(a, b)
        storm = sum(1 for _, q in zip(path, path[1:]) if self.map.areas[q[0]].name in self.storm) if self.storm else 0
        return self.map.cost(self.map.steps(path) + storm)

    def _room_at(self, m: str) -> dict:
        if not self.map:
            return {}
        a, r = self.room[m]
        return {"area": self.map.areas[a].name, "room": {"x": r["x"], "y": r["y"], "door": list(r["door"]),
                                                       "centre": list(r["centre"])}}

    def _machine_at(self, m: str, k: int) -> dict:
        if not self.map:
            return {}
        from .recipes import LOOK, title

        ms = self.room[m][1]["machines"]
        tile, stand = ms[k % len(ms)]
        tool = [f for f in self.functions.values() if f.module == m][k].name.split(".", 1)[1]
        return {"tile": list(tile), "stand": list(stand), "look": LOOK.get(tool, "table"), "title": title(tool)}

    def layout(self) -> dict:
        """Districts, workshops and machines (public), for the pixel client."""
        out = []
        for d in range(self.n_districts):
            mods = [m for m in self.modules if self.district_of[m] == d]
            out.append({"index": d, "name": DISTRICTS[d % len(DISTRICTS)] if self.n_districts > 1 else "town",
                        "workshops": [{"module": m, "kind": self.kind_of[m], "machines": [
                            {"name": f.name, "in": f.in_type, "out": f.out_type, **self._machine_at(m, k)}
                            for k, f in enumerate(f for f in self.functions.values() if f.module == m)],
                            **self._room_at(m)} for m in mods]})
        return {"theme": self.theme, "districts": out, "levels": [self.types_at[lv] for lv in range(self.levels)],
                "map": self.map.to_dict() if self.map else None}


def town_world(index: int = 1, districts: int = 1, machines: int = 6, shortcuts: bool = False) -> Universe:
    """The town-scale CodeWorld: 8 workshops per district, ``machines`` machines each."""
    return Universe(index, n_modules=8 * districts, fns_per_module=machines, levels=5,
                    types_per_level=3 if districts == 1 else 4, theme="town", shortcuts=shortcuts)
